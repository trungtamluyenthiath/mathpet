# Thư viện và kiểu chữ bên thứ ba

Đồ họa nhân vật, thú, NPC, tileset, quái/Boss, sáu icon vật phẩm, mũ/cánh trang trí, rương mở và các câu Toán được tạo riêng cho MathPet Adventure. Âm thanh trận đấu được tổng hợp bằng mã riêng qua Web Audio API của trình duyệt, không dùng bản ghi hoặc sample bên thứ ba. Những thành phần bên thứ ba đóng gói để chạy game hiện gồm Phaser và KaTeX. Không dùng ảnh/sprite Pokémon, CDN hoặc API ngoài khi chơi.

| Thành phần | Phiên bản | Nguồn | Giấy phép | Bản giấy phép trong game |
| --- | --- | --- | --- | --- |
| Phaser | 3.90.0 | [phaserjs/phaser](https://github.com/phaserjs/phaser) | MIT; Copyright (c) 2024 Richard Davey, Phaser Studio Inc. | [phaser.txt](public/licenses/phaser.txt) |
| Mã KaTeX | 0.19.0 | [KaTeX/KaTeX](https://github.com/KaTeX/KaTeX) | MIT; Copyright (c) 2013–2020 Khan Academy and other contributors | [katex.txt](public/licenses/katex.txt) |
| Kiểu chữ KaTeX | Đi cùng KaTeX 0.19.0 | Gói font trong `node_modules/katex/dist/fonts/` và nguồn KaTeX | **SIL Open Font License 1.1**; xem thông báo tác giả và Reserved Font Names trong bản giấy phép | [katex-fonts.txt](public/licenses/katex-fonts.txt) |

Giấy phép mã KaTeX và giấy phép kiểu chữ là hai giấy phép riêng. Metadata font ghi tác giả/Reserved Font Names, trong đó có KaTeX_Main và KaTeX_AMS; giữ nguyên kiểu chữ, không đổi tên hoặc sửa font trong dự án. CSS/font được Vite đóng gói cục bộ khi build; các bản thông báo trong `public/licenses/` được sao chép vào `dist/licenses/` để đi cùng bản phân phối.

`katex.txt` và `phaser.txt` được sao chép nguyên văn từ file LICENSE của đúng phiên bản đã cài. `katex-fonts.txt` giữ thông báo giấy phép kiểu chữ được kiểm tra từ nguồn và metadata font. Giấy phép các dependency/công cụ phát triển còn nằm trong từng gói npm; không có dịch vụ từ xa dùng để chấm Toán.

Ba PDF tập huấn SGK do người dùng cung cấp chỉ được tham khảo phạm vi kiến thức; không phân phối chúng hoặc sao chép hình/bài tập nguyên văn trong game. Xem [MATH_BANK_REVIEW.md](MATH_BANK_REVIEW.md) để biết phạm vi chương và nội dung tự biên soạn.

Repository chưa chọn giấy phép phân phối riêng cho mã nguồn, đồ họa và nội dung do dự án tạo. Giấy phép MIT/OFL của các thành phần bên thứ ba không tự cấp giấy phép cho toàn bộ dự án.

Nguồn các texture gốc của Flamy, Aquami, Leafy cùng 12 hình dạng và 24 biến thể trang trí, sáu icon vật phẩm, rương mở, Bóng Sai Dấu, Vệ Thần Phương Trình, Mộc Ảnh Biến Thiên, Chúa Bóng Tối Sai Lầm, tia sáng và âm thanh tùy chọn được ghi trong [tài liệu tài nguyên](src/assets/README.md). Chúng được vẽ/tổng hợp bằng mã riêng, không bổ sung asset bên thứ ba hoặc giấy phép dependency mới.
